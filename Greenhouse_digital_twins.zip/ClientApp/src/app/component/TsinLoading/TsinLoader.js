import React from 'react';

const TsinLoader = (props) => {
    return (
        <div className="spinner-wrapper">
            <div className="donut"></div>
        </div>
    )
};

export default TsinLoader;
